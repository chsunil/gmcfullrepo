<?php
/*
Template Name: Client Settings
*/
acf_form_head();
get_header();
?>

<div class="container-fluid p-0">
    <!-- Sidebar Toggle Button -->

    <div class="d-flex flex-column flex-md-row  wrapper">

        <!-- Improved Sticky LEFT Sidebar -->
        <aside class="sidebar  p-0 rounded shadow-sm position-sticky">

            <?php get_sidebar('custom'); ?>

        </aside>

        <!-- Main Content -->
        <main id="content" class="flex-fill my-4">

    <?php
    // 3) Capability check
    if ( ! is_user_logged_in() || ! current_user_can('manage_options') ) {
        echo '<p>You do not have permission to view this page.</p>';
        get_footer();
        exit;
    }

    // 4) Determine ACF “post” for current user
    $user_id = get_current_user_id();
    $post_id = 'user_' . $user_id;

    // 5) Try loading existing repeater data
    $nace_rows     = get_field('nace_codes',  $post_id) ?: [];
    $man_days_rows = get_field('man_days',    $post_id) ?: [];
         // Success message after save
        if ( isset($_GET['saved']) ) { ?>
   
  <div class="alert alert-warning alert-dismissible fade show"  data-dismiss="alert" aria-label="Close" role="alert">
  <strong>Settings saved.</strong>
  <!-- <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button> -->
</div>
      <?php  }

    // 6) If no data, show the ACF form to populate it
  

        // Replace 'group_client_settings' with your actual field‐group key
        acf_form([
            'post_id'      => $post_id,
            'field_groups' => ['group_client_settings'],
            'submit_value' => 'Save Settings',
            // reload page on save so we pick up the new data
            'return'       => add_query_arg('saved','1', get_permalink())
        ]);


        // 7) Otherwise, render the two tables

   
        ?>

       

        </main>
    </div>
</div>

<?php get_footer(); ?>