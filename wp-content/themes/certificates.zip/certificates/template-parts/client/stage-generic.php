<?php

/**
 * /template-parts/client/stage-generic.php
 */
/**
 * Generic per-stage form + PDF + Email + Next link.
 * Expects query var 'client_stage_args' => [
 *   'acf_args'     => array for acf_form(),
 *   'step_key'     => string, e.g. 'f03',
 *   'next_stage'   => string, e.g. 'f04',
 *   'group'        => ACF field‐group key,
 *   'real_post_id' => integer (0 if still creating)
 * ]
 */
$args         = get_query_var('client_stage_args', []);
$acf_args     = $args['acf_args']      ?? [];
$group        = $args['group']         ?? '';
$next_stage   = $args['next_stage']    ?? '';
$real_post_id = intval($args['real_post_id'] ?? 0);
$scheme     = get_field('certification_type', $real_post_id) ?: 'ems';
$step_key = sanitize_text_field($_GET['stage'] ?? 'draft');



// 2) Show a friendly “Saved successfully!” alert on top

// Add Bootstrap row to the form tag:

// 1) Render only the “Save” button via ACF and dont show if we are doing PDF
if ($step_key != 'f03') {
  acf_form($acf_args);
}
echo '<div class="mt-4">';

// 3) PDF‐generation block
if ($real_post_id) {
  $pdf_stages = get_certification_pdf()[$scheme] ?? [];

  // print_r ($pdf_stages);
  if (in_array($step_key, $pdf_stages, true)) {
    // ACF stores URL in a field named {step_key}_pdf
    $field_key = "{$step_key}_pdf";
    $pdf_url   = get_field($field_key, $real_post_id);

    echo '<div id="pdf-content-container" class="mb-3">';
    if ($pdf_url) {
      printf(
        '<object width="100%%" height="650" data="%s#zoom=95"></object>',
        esc_url($pdf_url)
      );
      echo '<button class="btn btn-danger btn-sm">Delete PDF</button>';
    } else {
      echo '<button class="btn btn-success btn-sm generate-pdf" data-post-id="' . $real_post_id . '" data-scheme="qms"
        data-stage="' . $step_key . '"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
<g clip-path="url(#clip0_421_946)">
<path d="M0 1.96875C0 0.882861 0.882861 0 1.96875 0H6.89062V3.9375C6.89062 4.48198 7.33052 4.92188 7.875 4.92188H11.8125V9.35156H5.41406C4.32817 9.35156 3.44531 10.2344 3.44531 11.3203V15.75H1.96875C0.882861 15.75 0 14.8671 0 13.7812V1.96875ZM11.8125 3.9375H7.875V0L11.8125 3.9375ZM5.41406 10.8281H6.39844C7.34897 10.8281 8.12109 11.6002 8.12109 12.5508C8.12109 13.5013 7.34897 14.2734 6.39844 14.2734H5.90625V15.2578C5.90625 15.5285 5.68477 15.75 5.41406 15.75C5.14336 15.75 4.92188 15.5285 4.92188 15.2578V13.7812V11.3203C4.92188 11.0496 5.14336 10.8281 5.41406 10.8281ZM6.39844 13.2891C6.80757 13.2891 7.13672 12.9599 7.13672 12.5508C7.13672 12.1417 6.80757 11.8125 6.39844 11.8125H5.90625V13.2891H6.39844ZM9.35156 10.8281H10.3359C11.1511 10.8281 11.8125 11.4895 11.8125 12.3047V14.2734C11.8125 15.0886 11.1511 15.75 10.3359 15.75H9.35156C9.08086 15.75 8.85938 15.5285 8.85938 15.2578V11.3203C8.85938 11.0496 9.08086 10.8281 9.35156 10.8281ZM10.3359 14.7656C10.6066 14.7656 10.8281 14.5441 10.8281 14.2734V12.3047C10.8281 12.034 10.6066 11.8125 10.3359 11.8125H9.84375V14.7656H10.3359ZM12.7969 11.3203C12.7969 11.0496 13.0184 10.8281 13.2891 10.8281H14.7656C15.0363 10.8281 15.2578 11.0496 15.2578 11.3203C15.2578 11.591 15.0363 11.8125 14.7656 11.8125H13.7812V12.7969H14.7656C15.0363 12.7969 15.2578 13.0184 15.2578 13.2891C15.2578 13.5598 15.0363 13.7812 14.7656 13.7812H13.7812V15.2578C13.7812 15.5285 13.5598 15.75 13.2891 15.75C13.0184 15.75 12.7969 15.5285 12.7969 15.2578V13.2891V11.3203Z" fill="#FFFCFC"/>
</g>
<defs>
<clipPath id="clip0_421_946">
<rect width="15.75" height="15.75" fill="white"/>
</clipPath>
</defs>
</svg> Generate PDF for '. $step_key.'</button>';
    }
    echo '</div>';

    // Send Email button (only if we have a template defined)
    if ($pdf_url) {
      $templates = get_certification_emails()[$scheme][$step_key] ?? null;
      $contact_email = get_field('contact_person_contact_email_new',$real_post_id);
      if ($templates) {
        ?>
      <button
  id="send-email-btn"
  class="btn btn-warning mb-3 send-email-btn"
  data-bs-toggle="modal"
  data-bs-target="#sendEmailModal"
  data-post-id="<?php echo esc_attr($real_post_id);?>"
  data-client-name="<?php echo esc_attr(get_the_title($real_post_id));?>"
  data-email="<?php echo esc_attr($contact_email);?>"
  data-pdf-url="<?php echo esc_url($pdf_url);?>"
  data-pdf-filename="<?php echo esc_attr(basename($pdf_url));?>">
  <i class="fa-regular fa-envelope"></i> Send Email
</button>
<?php
if ( $pdf_url && $templates ) {
  // gather modal data
  set_query_var('send_email_args', [
    'post_id'       => $real_post_id,
    'pdf_url'       => $pdf_url,
    'contact_email' => get_field('contact_person_contact_email_new',$real_post_id),
    'client_name'   => get_the_title($real_post_id),
  ]);
  // include the modal
  get_template_part('template-parts/client/send-email-modal');
}
?>

                   <?php 
      }
    }
  }
}



// 2) If we have a real post ID (i.e. the form has been saved at least once),
//    show a Next button that links to the next-stage URL.
if ($real_post_id && $next_stage):
  $next_url = add_query_arg(
    ['new_post_id' => $real_post_id, 'stage' => $next_stage],
    get_permalink()
  );
?>
  <div class="next-button-wrapper">
    <a href="<?php echo esc_url($next_url); ?>" class="btn btn-primary text-capitalize">
      Next: <?php echo esc_html($next_stage); ?>
    </a>
  </div>
<?php endif; ?>